'use client';

import { FormEvent, useEffect, useRef, useState } from 'react';

type Message = { role: 'user' | 'assistant'; content: string };
const starters = [
  { icon: '✦', title: 'Explain something', prompt: 'Explain a difficult topic in simple words.' },
  { icon: '↗', title: 'Plan a project', prompt: 'Help me make a simple step-by-step plan for a project.' },
  { icon: '✎', title: 'Write something', prompt: 'Help me write a clear, professional message.' },
  { icon: '⌘', title: 'Learn a new skill', prompt: 'Help me learn a useful new skill, one step at a time.' },
];

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const endRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages, busy]);

  async function send(text = input) {
    const clean = text.trim();
    if (!clean || busy) return;
    const next: Message[] = [...messages, { role: 'user', content: clean }];
    setMessages(next); setInput(''); setBusy(true); setError('');
    try {
      const response = await fetch('/api/chat', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next }),
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
      setMessages([...next, { role: 'assistant', content: data.reply }]);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not connect. Please try again.');
    } finally { setBusy(false); inputRef.current?.focus(); }
  }
  function onSubmit(e: FormEvent<HTMLFormElement>) { e.preventDefault(); void send(); }
  function newChat() { setMessages([]); setError(''); setInput(''); inputRef.current?.focus(); }

  return <main className="app-shell">
    <aside className="sidebar">
      <a className="brand" href="#" aria-label="Nova AI home"><span className="brand-mark">✦</span><span>nova<span className="brand-ai">ai</span></span></a>
      <button className="new-chat" onClick={newChat}><span>＋</span> New chat</button>
      <div className="side-label">YOUR SPACE</div>
      <div className="side-note"><span className="tiny-spark">✧</span><span>Your conversations will appear here as you chat.</span></div>
      <div className="sidebar-bottom"><div className="avatar">N</div><div><strong>Nova AI</strong><small>AI assistant</small></div><span className="online-dot" title="Ready" /></div>
    </aside>
    <section className="main-panel">
      <header className="topbar"><div className="mobile-brand"><span className="brand-mark">✦</span> nova<span className="brand-ai">ai</span></div><div className="model-pill"><span className="online-dot"/> AI assistant <span className="chevron">⌄</span></div><a className="top-link" href="#about">About</a></header>
      <div className={`conversation ${messages.length ? 'has-messages' : ''}`}>
        {messages.length === 0 ? <div className="welcome">
          <div className="welcome-icon"><span>✦</span></div>
          <div className="eyebrow">YOUR EVERYDAY AI COMPANION</div>
          <h1>Big ideas start<br/><span>with a question.</span></h1>
          <p className="welcome-copy">Ask anything. Work through an idea. Learn something new.<br className="desktop-break"/> Let’s figure it out together.</p>
          <div className="starter-grid">{starters.map((s) => <button className="starter-card" key={s.title} onClick={() => { setInput(s.prompt); inputRef.current?.focus(); }}><span className="starter-icon">{s.icon}</span><span className="starter-title">{s.title}</span><span className="starter-arrow">↗</span><small>{s.prompt}</small></button>)}</div>
        </div> : <div className="message-list">{messages.map((m, i) => <div className={`message-row ${m.role}`} key={i}>{m.role === 'assistant' && <div className="message-avatar">✦</div>}<div className="message-bubble">{m.content}</div></div>)}{busy && <div className="message-row assistant"><div className="message-avatar">✦</div><div className="message-bubble typing"><i/><i/><i/><span>Thinking</span></div></div>}{error && <div className="error-box">{error}</div>}<div ref={endRef}/></div>}
      </div>
      <div className="composer-wrap"><form className="composer" onSubmit={onSubmit}><textarea ref={inputRef} value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); } }} placeholder="Message Nova AI..." rows={1} aria-label="Message Nova AI"/><div className="composer-footer"><span className="hint">↵ send <span>·</span> shift + ↵ for a new line</span><button className="send-button" type="submit" disabled={!input.trim() || busy} aria-label="Send message">↑</button></div></form><p className="disclaimer">Nova AI can make mistakes. Check important information.</p></div>
      <footer id="about" className="page-footer">Made to help you think, create, and move forward. <span>✦</span></footer>
    </section>
  </main>;
}
