import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Nova AI — Your helpful AI assistant',
  description: 'Ask questions, explore ideas, and get practical help with Nova AI.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
